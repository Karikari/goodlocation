package com.karikari.goodlocation;

public class Cordinate {

    public Double lat;
    public Double lng;
}
